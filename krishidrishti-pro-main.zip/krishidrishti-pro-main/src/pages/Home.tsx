import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  Leaf, Bug, TrendingUp, FlaskConical, BarChart3,
  Mic, CalendarDays, FileCheck, Users, Video,
  ArrowRight, Shield, Zap, Smartphone
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const metrics = [
  { value: "10", label: "AI Modules" },
  { value: "9×", label: "ROI First Season" },
  { value: "65%", label: "Less Pesticide" },
  { value: "5M", label: "Farmers by 2028" },
];

const modules = [
  {
    icon: Leaf,
    name: "Snap & Diagnose",
    type: "Reactive AI",
    desc: "Photo a leaf → 38 disease classes + severity + remedy in 4 seconds, fully offline.",
  },
  {
    icon: Bug,
    name: "PestGuard Agentic System",
    type: "Agentic AI",
    desc: "3 autonomous agents: detect at 2% infestation → decide treatment → execute targeted spray. ₹0 hardware.",
    highlight: true,
  },
  {
    icon: TrendingUp,
    name: "Yield Predictor",
    type: "Predictive AI",
    desc: "Weather + soil + crop data → kg/acre forecast with confidence range using Random Forest.",
  },
  {
    icon: BarChart3,
    name: "Smart Market Predictor",
    type: "Predictive AI",
    desc: "LSTM model forecasts Mandi prices 7–30 days ahead — best date, best Mandi, expected price.",
  },
  {
    icon: FlaskConical,
    name: "AI Soil Scanner",
    type: "Reactive AI",
    desc: "Photo soil → type + pH estimate + top 3 crop recommendations. No lab required.",
  },
  {
    icon: Mic,
    name: "KrishiBot Voice Agent",
    type: "Conversational AI",
    desc: "Speak in your language → ICAR-backed expert answer in <3 seconds. 5 Indian languages supported.",
  },
  {
    icon: CalendarDays,
    name: "Crop Calendar",
    type: "Proactive AI",
    desc: "Personalised daily schedule + morning voice briefings + pest alerts + irrigation reminders.",
  },
  {
    icon: FileCheck,
    name: "Scheme Matcher",
    type: "Matching AI",
    desc: "Auto-identifies eligible schemes from 46+ government programs including PM-KISAN, PMFBY, SMAM.",
  },
  {
    icon: Users,
    name: "Farmer Community",
    type: "Community",
    desc: "Peer Q&A, mentor matching, voice-first wisdom archive, and regional pest heatmaps.",
  },
  {
    icon: Video,
    name: "Video Learning Library",
    type: "Learning",
    desc: "AI-curated, language-filtered, offline-capable video curriculum for every farming skill.",
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.06 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" as const } },
};

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(142_76%_36%/0.08),transparent_60%)]" />
        <div className="relative max-w-5xl mx-auto px-6 pt-16 pb-20 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border bg-card mb-6">
              <div className="w-5 h-5 rounded bg-primary flex items-center justify-center">
                <Leaf className="w-3 h-3 text-primary-foreground" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">KrishiDrishti 3.0 + PestGuard</span>
              <Badge className="text-[9px] bg-alert text-alert-foreground border-0">NEW</Badge>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-6xl font-bold tracking-tight leading-[1.1]"
          >
            Precision in
            <br />
            <span className="text-primary">every grain.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto font-reading leading-relaxed"
          >
            India's first platform combining autonomous agentic pest protection, AI diagnostics,
            predictive market intelligence, and a multilingual voice agent — in one app, on any Android phone.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-8 flex items-center justify-center gap-3"
          >
            <Button
              size="lg"
              onClick={() => navigate("/dashboard")}
              className="bg-foreground text-background hover:bg-foreground/90 px-8 h-12 text-sm font-semibold"
            >
              Get Started <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button variant="outline" size="lg" className="h-12 px-6 text-sm" onClick={() => {
              document.getElementById("modules")?.scrollIntoView({ behavior: "smooth" });
            }}>
              Explore Modules
            </Button>
          </motion.div>

          {/* Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="mt-16 grid grid-cols-4 gap-6 max-w-2xl mx-auto"
          >
            {metrics.map((m) => (
              <div key={m.label} className="text-center">
                <p className="text-3xl font-bold font-mono-data tracking-tight">{m.value}</p>
                <p className="text-[11px] text-muted-foreground mt-1">{m.label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* PestGuard Highlight */}
      <section className="border-y bg-card">
        <div className="max-w-5xl mx-auto px-6 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10"
          >
            <Badge className="bg-alert text-alert-foreground border-0 mb-3">Core Innovation</Badge>
            <h2 className="text-3xl font-bold tracking-tight">PestGuard Agentic AI</h2>
            <p className="text-sm text-muted-foreground mt-2 max-w-lg mx-auto">
              Every other agri-app waits for the farmer. PestGuard acts before the farmer knows there is a problem.
            </p>
          </motion.div>

          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: Bug, title: "Detection Agent", desc: "Scheduled phone scans (6AM, 12PM, 6PM) + IoT sensors detect pest at 2% severity — before visible damage.", step: "01" },
              { icon: Shield, title: "Decision Agent", desc: "Claude/GPT-4 analyses spread rate, weather, soil moisture, crop stage → precision treatment plan with cost-benefit.", step: "02" },
              { icon: Zap, title: "Execution Agent", desc: "WhatsApp alert: APPROVE / DELAY. On approval, pinpointed zone map + targeted spray guidance. 65% less chemical.", step: "03" },
            ].map((agent, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className="border rounded-lg p-6 bg-background shadow-ceramic"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-9 h-9 rounded-md bg-alert/10 flex items-center justify-center">
                    <agent.icon className="w-4 h-4 text-alert" />
                  </div>
                  <span className="text-2xl font-bold font-mono-data text-muted/30">{agent.step}</span>
                </div>
                <h3 className="text-sm font-semibold">{agent.title}</h3>
                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{agent.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* All Modules */}
      <section id="modules" className="max-w-5xl mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold tracking-tight">10 AI-Powered Modules</h2>
          <p className="text-sm text-muted-foreground mt-2">Snap. Speak. Detect. Act. Grow Together.</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid grid-cols-2 gap-4"
        >
          {modules.map((mod, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              whileHover={{ y: -4 }}
              className={`flex items-start gap-4 p-5 rounded-lg border bg-card shadow-ceramic transition-colors cursor-default ${
                mod.highlight ? "border-t-4 border-t-alert" : ""
              }`}
            >
              <div className={`w-10 h-10 rounded-md flex items-center justify-center shrink-0 ${
                mod.highlight ? "bg-alert/10" : "bg-primary/10"
              }`}>
                <mod.icon className={`w-5 h-5 ${mod.highlight ? "text-alert" : "text-primary"}`} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold">{mod.name}</h3>
                  <Badge variant="outline" className="text-[9px]">{mod.type}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{mod.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Tech Stack */}
      <section className="border-t bg-card">
        <div className="max-w-5xl mx-auto px-6 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h2 className="text-3xl font-bold tracking-tight">Built for the Field</h2>
            <p className="text-sm text-muted-foreground mt-2">₹0 hardware cost — uses farmer's existing ₹4,000 phone.</p>
          </motion.div>

          <div className="grid grid-cols-4 gap-4">
            {[
              { icon: Smartphone, label: "Offline-First", desc: "All AI models run on-device via TFLite" },
              { icon: Shield, label: "₹0 Hardware", desc: "Uses existing Android 8+ phone" },
              { icon: Mic, label: "5 Languages", desc: "Kannada, Hindi, Tamil, Telugu, English" },
              { icon: Zap, label: "<4s Diagnosis", desc: "MobileNetV2 inference on any phone" },
            ].map((feat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-5 rounded-lg border bg-background"
              >
                <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <feat.icon className="w-5 h-5 text-primary" />
                </div>
                <p className="text-sm font-semibold">{feat.label}</p>
                <p className="text-[11px] text-muted-foreground mt-1">{feat.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-5xl mx-auto px-6 py-20 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="text-3xl font-bold tracking-tight">Every farmer protected,<br />every generation empowered.</h2>
          <p className="text-sm text-muted-foreground mt-3 max-w-md mx-auto font-reading">
            Join the agricultural revolution. Start using KrishiDrishti 3.0 today.
          </p>
          <Button
            size="lg"
            onClick={() => navigate("/dashboard")}
            className="mt-8 bg-foreground text-background hover:bg-foreground/90 px-10 h-12 text-sm font-semibold"
          >
            Get Started <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 px-6">
        <div className="max-w-5xl mx-auto flex items-center justify-between text-[11px] text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-primary flex items-center justify-center">
              <Leaf className="w-3 h-3 text-primary-foreground" />
            </div>
            <span className="font-medium text-foreground">KrishiDrishti 3.0</span>
          </div>
          <p>Build Crew · KLE Society's S Nijalingappa College, Bengaluru</p>
          <p>National Hackathon: Tech for Agriculture · ACM · Jain University · IBM</p>
        </div>
      </footer>
    </div>
  );
}
