import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { BarChart3, TrendingUp, TrendingDown, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const priceData = [
  { day: "Mar 10", price: 2400 }, { day: "Mar 11", price: 2380 }, { day: "Mar 12", price: 2450 },
  { day: "Mar 13", price: 2420 }, { day: "Mar 14", price: 2350 }, { day: "Mar 15", price: 2290 },
  { day: "Mar 16", price: 2200 }, { day: "Mar 17", price: 2150 }, { day: "Mar 18", price: 2100 },
  { day: "Mar 19", price: 2080 },
];

const mandis = [
  { name: "Kolar APMC", price: "₹2,200/q", trend: -8.3, best: false },
  { name: "Bangalore APMC", price: "₹2,450/q", trend: -3.1, best: true },
  { name: "Chikkaballapur", price: "₹2,180/q", trend: -9.2, best: false },
];

export default function MarketPredictor() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Smart Market Predictor</h2>
          <p className="text-sm text-muted-foreground mt-1">LSTM model forecasts Mandi prices 7–30 days ahead</p>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 bg-card border rounded-lg p-6 shadow-ceramic">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" /> Tomato Price Forecast
              </h3>
              <div className="flex gap-2">
                <Badge variant="outline" className="text-[10px]">7-Day</Badge>
                <Badge variant="secondary" className="text-[10px]">30-Day</Badge>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={priceData}>
                  <defs>
                    <linearGradient id="priceGradFull" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(142, 10%, 90%)" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10 }} domain={[2000, 2600]} />
                  <Tooltip contentStyle={{ fontSize: 11, borderRadius: 6 }}
                    formatter={(value: number) => [`₹${value}/q`, "Price"]} />
                  <Area type="monotone" dataKey="price" stroke="hsl(142, 76%, 36%)" strokeWidth={2} fill="url(#priceGradFull)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">Confidence: 92% · MAPE: 6.8% on 30-day forecast</p>
          </div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" /> Best Mandi
            </h3>
            <div className="space-y-3">
              {mandis.map((m, i) => (
                <motion.div key={i} whileHover={{ y: -2 }}
                  className={`p-3 border rounded-md cursor-pointer transition-colors ${m.best ? "border-primary bg-primary/5" : "hover:bg-muted/30"}`}
                >
                  <div className="flex justify-between items-center text-xs">
                    <div>
                      <p className="font-medium text-foreground">{m.name}</p>
                      {m.best && <Badge className="text-[9px] mt-1 bg-primary text-primary-foreground border-0">Best Price</Badge>}
                    </div>
                    <div className="text-right">
                      <p className="font-mono-data font-bold text-foreground">{m.price}</p>
                      <span className={`flex items-center gap-0.5 text-[10px] ${m.trend < 0 ? "text-alert" : "text-primary"}`}>
                        {m.trend < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                        {m.trend}%
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground mt-4">Suggestion: Sell at Bangalore APMC within 3 days or consider cold storage.</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
