import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { Bug, Shield, Clock, MapPin, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const agents = [
  {
    name: "Detection Agent",
    status: "Active",
    desc: "Scheduled smartphone scans (6AM, 12PM, 6PM) + IoT sensor triggers. YOLOv8 on-device inference.",
    icon: Bug,
    metric: "2.3% infestation detected",
  },
  {
    name: "Decision Agent",
    status: "Processing",
    desc: "Claude/GPT-4 analyses spread rate, IMD 7-day weather, soil moisture, and crop stage → precision treatment plan.",
    icon: Shield,
    metric: "Treatment plan ready",
  },
  {
    name: "Execution Agent",
    status: "Awaiting Approval",
    desc: "WhatsApp alert with APPROVE/DELAY. On approval, sends pinpointed zone map for targeted spray.",
    icon: Zap,
    metric: "65% less chemical",
  },
];

const heatmapZones = [
  { zone: "N1", level: "low" }, { zone: "N2", level: "low" }, { zone: "N3", level: "medium" }, { zone: "N4", level: "critical" },
  { zone: "S1", level: "low" }, { zone: "S2", level: "low" }, { zone: "S3", level: "low" }, { zone: "S4", level: "medium" },
  { zone: "E1", level: "low" }, { zone: "E2", level: "medium" }, { zone: "E3", level: "low" }, { zone: "E4", level: "low" },
  { zone: "W1", level: "low" }, { zone: "W2", level: "low" }, { zone: "W3", level: "low" }, { zone: "W4", level: "low" },
];

const levelColors: Record<string, string> = {
  low: "bg-primary/10",
  medium: "bg-alert/20",
  critical: "bg-alert/60",
};

export default function PestMonitoring() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">PestGuard Agentic System</h2>
          <p className="text-sm text-muted-foreground mt-1">3 autonomous agents: detect → decide → execute. ₹0 hardware cost.</p>
        </div>

        {/* Agents Pipeline */}
        <div className="grid grid-cols-3 gap-4">
          {agents.map((a, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              className="bg-card border rounded-lg p-6 shadow-ceramic"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                  <a.icon className="w-4 h-4 text-primary" />
                </div>
                <Badge variant={a.status === "Active" ? "default" : "secondary"} className="text-[10px]">{a.status}</Badge>
              </div>
              <h3 className="text-sm font-semibold">{a.name}</h3>
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{a.desc}</p>
              <p className="text-xs font-medium text-primary mt-3">{a.metric}</p>
            </motion.div>
          ))}
        </div>

        {/* Farm Heatmap */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Farm Pest Heatmap</h3>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {heatmapZones.map((z) => (
                <motion.div
                  key={z.zone}
                  whileHover={{ scale: 1.05 }}
                  className={`aspect-square rounded-md flex items-center justify-center text-[11px] font-mono-data font-medium border ${levelColors[z.level]} cursor-pointer`}
                >
                  {z.zone}
                </motion.div>
              ))}
            </div>
            <div className="flex gap-4 mt-4 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-primary/10 border" /> Safe</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-alert/20 border" /> Moderate</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-alert/60 border" /> Critical</span>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" /> Treatment Timeline
            </h3>
            <div className="space-y-4">
              {[
                { time: "06:00", event: "Morning scan completed", status: "done" },
                { time: "06:12", event: "Armyworm detected — N4 sector", status: "alert" },
                { time: "06:15", event: "Decision Agent: Treatment plan generated", status: "done" },
                { time: "06:16", event: "WhatsApp alert sent — Awaiting approval", status: "pending" },
              ].map((e, i) => (
                <div key={i} className="flex gap-3 text-xs">
                  <span className="font-mono-data text-muted-foreground w-12 shrink-0">{e.time}</span>
                  <div className={`w-2 h-2 rounded-full mt-1 shrink-0 ${
                    e.status === "alert" ? "bg-alert" : e.status === "done" ? "bg-primary" : "bg-muted-foreground"
                  }`} />
                  <span className={e.status === "alert" ? "text-alert font-medium" : "text-foreground"}>{e.event}</span>
                </div>
              ))}
            </div>
            <Button className="w-full mt-6 bg-foreground text-background hover:bg-foreground/90">
              Approve Treatment Plan
            </Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
