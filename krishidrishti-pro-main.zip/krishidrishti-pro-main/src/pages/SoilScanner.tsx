import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { FlaskConical, Camera, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

const nutrients = [
  { label: "Nitrogen (N)", value: 72, unit: "kg/ha", status: "Adequate" },
  { label: "Phosphorus (P)", value: 45, unit: "kg/ha", status: "Low" },
  { label: "Potassium (K)", value: 88, unit: "kg/ha", status: "Adequate" },
];

const recommendations = [
  { crop: "Paddy (IR-64)", suitability: 92 },
  { crop: "Maize (Hybrid)", suitability: 87 },
  { crop: "Groundnut", suitability: 78 },
];

export default function SoilScanner() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">AI Soil Scanner</h2>
          <p className="text-sm text-muted-foreground mt-1">Photo soil → type + pH estimate + top 3 crops, no lab required</p>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <motion.div whileHover={{ y: -2 }}
            className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:border-primary/50 transition-colors"
          >
            <FlaskConical className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-sm font-semibold">Scan Soil</p>
            <p className="text-xs text-muted-foreground mt-1">Photograph soil sample</p>
            <div className="flex gap-2 mt-4">
              <Button size="sm" variant="outline"><Camera className="w-3.5 h-3.5 mr-1" /> Camera</Button>
              <Button size="sm" variant="outline"><Upload className="w-3.5 h-3.5 mr-1" /> Upload</Button>
            </div>
          </motion.div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4">NPK Analysis</h3>
            <div className="space-y-4">
              {nutrients.map((n, i) => (
                <div key={i}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">{n.label}</span>
                    <span className="font-mono-data font-bold text-foreground">{n.value} {n.unit}</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${n.value}%` }} transition={{ duration: 1 }}
                      className={`h-full rounded-full ${n.value > 60 ? "bg-primary" : "bg-alert"}`} />
                  </div>
                  <p className={`text-[10px] mt-1 ${n.status === "Low" ? "text-alert" : "text-primary"}`}>{n.status}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t text-xs text-muted-foreground space-y-1">
              <div className="flex justify-between"><span>Soil Type</span><span className="font-medium text-foreground">Sandy Loam</span></div>
              <div className="flex justify-between"><span>pH Level</span><span className="font-mono-data font-medium text-foreground">6.8</span></div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4">Recommended Crops</h3>
            <div className="space-y-3">
              {recommendations.map((r, i) => (
                <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.15 }}
                  className="p-3 border rounded-md"
                >
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-medium">{r.crop}</span>
                    <span className="font-mono-data text-primary font-bold">{r.suitability}%</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${r.suitability}%` }} transition={{ duration: 0.8 }}
                      className="h-full bg-primary rounded-full" />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
