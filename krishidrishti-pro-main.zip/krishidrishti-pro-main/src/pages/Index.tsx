import DashboardLayout from "@/components/DashboardLayout";
import PestGuardCard from "@/components/modules/PestGuardCard";
import SoilScannerCard from "@/components/modules/SoilScannerCard";
import MarketPredictorCard from "@/components/modules/MarketPredictorCard";
import YieldPredictorCard from "@/components/modules/YieldPredictorCard";
import WeatherCard from "@/components/modules/WeatherCard";
import CropCalendarWidget from "@/components/modules/CropCalendarWidget";
import CommunityWidget from "@/components/modules/CommunityWidget";
import QuickActions from "@/components/modules/QuickActions";

export default function Index() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Good morning, Farmer</h2>
          <p className="text-sm text-muted-foreground mt-1">Precision in every grain.</p>
        </div>

        <QuickActions />

        {/* Bento Grid */}
        <div className="grid grid-cols-4 gap-4">
          <div className="col-span-2">
            <PestGuardCard />
          </div>
          <div className="col-span-1">
            <SoilScannerCard />
          </div>
          <div className="col-span-1">
            <WeatherCard />
          </div>
          <div className="col-span-2">
            <MarketPredictorCard />
          </div>
          <div className="col-span-1">
            <YieldPredictorCard />
          </div>
          <div className="col-span-1">
            <CropCalendarWidget />
          </div>
        </div>

        {/* Community Feed */}
        <CommunityWidget />
      </div>
    </DashboardLayout>
  );
}
