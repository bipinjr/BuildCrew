import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { CalendarDays, AlertCircle, CheckCircle2, Clock, Volume2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const todayTasks = [
  { time: "06:00", task: "PestGuard morning scan", status: "done", urgent: false },
  { time: "07:00", task: "Spray neem oil — N4 sector (Armyworm)", status: "pending", urgent: true },
  { time: "09:00", task: "Irrigate paddy field B2", status: "pending", urgent: false },
  { time: "11:00", task: "Soil test collection — S2", status: "upcoming", urgent: false },
  { time: "14:00", task: "Market check — Tomato at Kolar APMC", status: "upcoming", urgent: false },
  { time: "18:00", task: "PestGuard evening scan", status: "upcoming", urgent: false },
];

const weekView = [
  { day: "Mon", tasks: 4, alerts: 0 },
  { day: "Tue", tasks: 3, alerts: 1 },
  { day: "Wed", tasks: 5, alerts: 2 },
  { day: "Thu", tasks: 3, alerts: 0 },
  { day: "Fri", tasks: 4, alerts: 0 },
  { day: "Sat", tasks: 2, alerts: 0 },
  { day: "Sun", tasks: 1, alerts: 0 },
];

export default function CropCalendar() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Crop Calendar</h2>
            <p className="text-sm text-muted-foreground mt-1">Personalised daily schedule + morning voice briefings + pest alerts</p>
          </div>
          <Button variant="outline" size="sm"><Volume2 className="w-3.5 h-3.5 mr-1" /> Morning Briefing</Button>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {weekView.map((d, i) => (
            <motion.div key={i} whileHover={{ y: -2 }}
              className={`bg-card border rounded-lg p-3 text-center cursor-pointer ${i === 2 ? "border-primary" : ""}`}
            >
              <p className="text-xs font-medium">{d.day}</p>
              <p className="text-lg font-bold font-mono-data mt-1">{d.tasks}</p>
              <p className="text-[10px] text-muted-foreground">tasks</p>
              {d.alerts > 0 && <Badge className="text-[9px] mt-1 bg-alert text-alert-foreground border-0">{d.alerts} alert</Badge>}
            </motion.div>
          ))}
        </div>

        <div className="bg-card border rounded-lg p-6 shadow-ceramic">
          <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-primary" /> Today — Wednesday, March 16
          </h3>
          <div className="space-y-3">
            {todayTasks.map((t, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}
                className={`flex items-center gap-4 p-3 rounded-md border ${t.urgent ? "border-alert bg-alert/5" : ""}`}
              >
                <span className="font-mono-data text-xs text-muted-foreground w-12">{t.time}</span>
                {t.status === "done" ? (
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                ) : t.urgent ? (
                  <AlertCircle className="w-4 h-4 text-alert shrink-0" />
                ) : (
                  <Clock className="w-4 h-4 text-muted-foreground shrink-0" />
                )}
                <span className={`text-sm flex-1 ${t.status === "done" ? "line-through text-muted-foreground" : t.urgent ? "font-medium" : ""}`}>
                  {t.task}
                </span>
                <Badge variant={t.status === "done" ? "secondary" : t.status === "pending" ? "default" : "outline"} className="text-[10px]">
                  {t.status}
                </Badge>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
