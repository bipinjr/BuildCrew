import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { FileCheck, ChevronRight, IndianRupee, CheckCircle2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const schemes = [
  {
    name: "PM-KISAN",
    desc: "₹6,000/year direct income support to farmer families",
    eligibility: 98,
    amount: "₹6,000/year",
    status: "Eligible",
  },
  {
    name: "PMFBY (Crop Insurance)",
    desc: "Premium subsidy up to 98% for Kharif crops. Protects against natural calamities.",
    eligibility: 92,
    amount: "Up to ₹2L coverage",
    status: "Eligible",
  },
  {
    name: "SMAM Subsidy",
    desc: "50-80% subsidy on farm machinery including sprayers, seed drills, and rotavators.",
    eligibility: 85,
    amount: "50-80% subsidy",
    status: "Eligible",
  },
  {
    name: "Soil Health Card Scheme",
    desc: "Free soil testing and nutrient-based crop recommendations from nearest KVK.",
    eligibility: 100,
    amount: "Free",
    status: "Applied",
  },
];

export default function SchemeMatcher() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleSwipe = (direction: "right" | "left") => {
    if (currentIndex < schemes.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const current = schemes[currentIndex];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Scheme Matcher</h2>
          <p className="text-sm text-muted-foreground mt-1">Auto-identifies eligible schemes from 46+ government programs</p>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Tinder-style Card */}
          <div className="flex flex-col items-center">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full bg-card border rounded-lg p-8 shadow-ceramic"
            >
              <Badge className="bg-primary text-primary-foreground border-0">{current.status}</Badge>
              <h3 className="text-xl font-bold mt-4 tracking-tight">{current.name}</h3>
              <p className="text-sm text-muted-foreground mt-2 font-reading leading-relaxed">{current.desc}</p>
              
              <div className="flex items-center gap-2 mt-4">
                <IndianRupee className="w-4 h-4 text-primary" />
                <span className="text-sm font-semibold">{current.amount}</span>
              </div>

              <div className="mt-4">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Eligibility Match</span>
                  <span className="font-mono-data font-bold text-primary">{current.eligibility}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${current.eligibility}%` }}
                    className="h-full bg-primary rounded-full" />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button variant="outline" size="lg" className="flex-1" onClick={() => handleSwipe("left")}>
                  <X className="w-4 h-4 mr-1" /> Skip
                </Button>
                <Button size="lg" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => handleSwipe("right")}>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Save
                </Button>
              </div>
            </motion.div>
            <p className="text-[11px] text-muted-foreground mt-3">{currentIndex + 1} of {schemes.length} schemes</p>
          </div>

          {/* All Schemes List */}
          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-primary" /> All Eligible Schemes ({schemes.length})
            </h3>
            <div className="space-y-3">
              {schemes.map((s, i) => (
                <motion.div key={i} whileHover={{ x: 4 }}
                  className="flex items-center justify-between p-3 rounded-md border cursor-pointer hover:bg-muted/30 transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium">{s.name}</p>
                    <p className="text-[11px] text-muted-foreground">{s.amount}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono-data text-primary">{s.eligibility}%</span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
