import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { Video, Play, Clock, Globe, Download, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

const videos = [
  { title: "Fall Armyworm Management in Maize", duration: "12:34", lang: "Kannada", views: "2.4K", category: "Pest Control", offline: true },
  { title: "Organic Farming — Complete Guide for Beginners", duration: "28:15", lang: "Hindi", views: "5.1K", category: "Organic", offline: true },
  { title: "Drip Irrigation Setup — Step by Step", duration: "18:42", lang: "English", views: "3.8K", category: "Irrigation", offline: false },
  { title: "Soil Testing at Home — Simple Methods", duration: "8:20", lang: "Tamil", views: "1.9K", category: "Soil Health", offline: true },
  { title: "PM-KISAN Application — Complete Process", duration: "15:10", lang: "Hindi", views: "12.3K", category: "Schemes", offline: false },
  { title: "Climate-Smart Paddy Cultivation", duration: "22:05", lang: "Kannada", views: "4.2K", category: "Climate", offline: true },
];

const categories = ["All", "Pest Control", "Organic", "Irrigation", "Soil Health", "Schemes", "Climate"];

export default function VideoLearning() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Video Learning Library</h2>
          <p className="text-sm text-muted-foreground mt-1">AI-curated, language-filtered, offline-capable video curriculum</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-10" placeholder="Search videos..." />
          </div>
          <div className="flex gap-1">
            {categories.map((c) => (
              <Badge key={c} variant={c === "All" ? "default" : "outline"} className="text-[10px] cursor-pointer">{c}</Badge>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {videos.map((v, i) => (
            <motion.div key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ y: -4 }}
              className="bg-card border rounded-lg overflow-hidden shadow-ceramic cursor-pointer group"
            >
              {/* Video Thumbnail Placeholder */}
              <div className="aspect-video bg-muted flex items-center justify-center relative">
                <div className="w-12 h-12 rounded-full bg-foreground/80 flex items-center justify-center group-hover:bg-primary transition-colors">
                  <Play className="w-5 h-5 text-background ml-0.5" />
                </div>
                <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-foreground/70 text-background text-[10px] font-mono-data">
                  {v.duration}
                </div>
                {v.offline && (
                  <div className="absolute top-2 left-2">
                    <Badge className="text-[9px] bg-primary text-primary-foreground border-0">
                      <Download className="w-2.5 h-2.5 mr-0.5" /> Offline
                    </Badge>
                  </div>
                )}
              </div>

              <div className="p-4">
                <Badge variant="outline" className="text-[9px] mb-2">{v.category}</Badge>
                <h3 className="text-sm font-semibold leading-snug font-reading">{v.title}</h3>
                <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Globe className="w-2.5 h-2.5" />{v.lang}</span>
                  <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" />{v.duration}</span>
                  <span>{v.views} views</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
