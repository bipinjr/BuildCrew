import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { Mic, Volume2, Globe, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const conversation = [
  { role: "user", text: "What is the best remedy for fall armyworm in maize?", lang: "English" },
  { role: "bot", text: "For early-stage fall armyworm infestation (below 5%), apply neem oil (5ml/L) at dusk. For higher severity, use Emamectin benzoate 5% SG at 0.4g/L. Ensure spray reaches the whorl. Source: ICAR Maize Research Centre.", lang: "English" },
  { role: "user", text: "ಬೆಳೆಗೆ ನೀರು ಯಾವಾಗ ಕೊಡಬೇಕು?", lang: "Kannada" },
  { role: "bot", text: "ಮೆಕ್ಕೆಜೋಳಕ್ಕೆ ಬಿತ್ತನೆ ನಂತರ 20-25 ದಿನಗಳಲ್ಲಿ ಮೊದಲ ನೀರಾವರಿ ನೀಡಿ. ಮಣ್ಣಿನ ತೇವಾಂಶ 40% ಕ್ಕಿಂತ ಕೆಳಗೆ ಬಂದಾಗ ನೀರು ಕೊಡಿ. Source: UAS Dharwad.", lang: "Kannada" },
];

const languages = ["English", "Kannada", "Hindi", "Tamil", "Telugu"];

export default function VoiceAssistant() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">KrishiBot Voice Agent</h2>
          <p className="text-sm text-muted-foreground mt-1">Speak in your language → ICAR-backed expert answer in &lt;3 seconds</p>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 bg-card border rounded-lg p-6 shadow-ceramic">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-primary" /> Conversation
              </h3>
              <div className="flex gap-1">
                {languages.map((l) => (
                  <Badge key={l} variant={l === "English" ? "default" : "outline"} className="text-[9px] cursor-pointer">{l}</Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4 max-h-[400px] overflow-y-auto">
              {conversation.map((msg, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.15 }}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div className={`max-w-[80%] p-4 rounded-lg text-sm ${
                    msg.role === "user" ? "bg-foreground text-background" : "bg-muted text-foreground"
                  }`}>
                    <p className="font-reading leading-relaxed">{msg.text}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className={`text-[9px] ${msg.role === "user" ? "border-background/30 text-background/60" : ""}`}>
                        <Globe className="w-2.5 h-2.5 mr-1" />{msg.lang}
                      </Badge>
                      {msg.role === "bot" && <Volume2 className="w-3 h-3 text-muted-foreground cursor-pointer hover:text-primary" />}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Voice Input */}
            <div className="mt-6 flex items-center gap-3">
              <motion.button whileTap={{ scale: 0.95 }}
                className="w-14 h-14 rounded-full bg-primary flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
              >
                <Mic className="w-6 h-6 text-primary-foreground" />
              </motion.button>
              <div>
                <p className="text-sm font-medium">Tap to speak</p>
                <p className="text-[11px] text-muted-foreground">Whisper STT + Coqui TTS · Offline 8B model</p>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4">Knowledge Base</h3>
            <div className="space-y-3 text-xs">
              {[
                { label: "ICAR Documents", count: "40,000+" },
                { label: "Languages", count: "5" },
                { label: "Avg Response", count: "<3s" },
                { label: "Offline Model", count: "Llama 3 8B" },
                { label: "STT Engine", count: "Whisper" },
                { label: "TTS Engine", count: "Coqui" },
              ].map((item, i) => (
                <div key={i} className="flex justify-between p-2 rounded-md border">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className="font-mono-data font-medium text-foreground">{item.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
