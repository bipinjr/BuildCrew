import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const data = [
  { month: "Jan", predicted: 22, actual: 21 },
  { month: "Feb", predicted: 24, actual: 23 },
  { month: "Mar", predicted: 26, actual: null },
  { month: "Apr", predicted: 25, actual: null },
];

const factors = [
  { name: "Soil Quality", impact: "High", value: "+3.2 bags" },
  { name: "Rainfall", impact: "Medium", value: "+1.1 bags" },
  { name: "Temperature", impact: "Low", value: "-0.5 bags" },
  { name: "Pest Pressure", impact: "High", value: "-2.1 bags" },
];

export default function YieldPredictor() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Yield Predictor</h2>
          <p className="text-sm text-muted-foreground mt-1">Weather + soil + crop data → kg/acre forecast with confidence range</p>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" /> Monthly Yield Trend (Bags/Acre)
            </h3>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(142, 10%, 90%)" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ fontSize: 11, borderRadius: 6 }} />
                  <Bar dataKey="predicted" fill="hsl(142, 76%, 36%)" radius={[4, 4, 0, 0]} name="Predicted" />
                  <Bar dataKey="actual" fill="hsl(210, 40%, 85%)" radius={[4, 4, 0, 0]} name="Actual" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4">Impact Factors</h3>
            <div className="space-y-3">
              {factors.map((f, i) => (
                <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.1 }}
                  className="flex items-center justify-between text-xs p-2 rounded-md border"
                >
                  <div>
                    <p className="font-medium text-foreground">{f.name}</p>
                    <Badge variant="outline" className="text-[9px] mt-1">{f.impact} impact</Badge>
                  </div>
                  <span className={`font-mono-data font-semibold ${f.value.startsWith("+") ? "text-primary" : "text-alert"}`}>{f.value}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-card border rounded-lg p-6 shadow-ceramic">
          <h3 className="text-sm font-semibold mb-3">Model Details</h3>
          <div className="grid grid-cols-4 gap-4 text-xs text-muted-foreground">
            <div><span className="block text-foreground font-medium">Model</span>Random Forest Regressor</div>
            <div><span className="block text-foreground font-medium">MAPE</span><span className="font-mono-data">6.8%</span></div>
            <div><span className="block text-foreground font-medium">Features</span>12 input variables</div>
            <div><span className="block text-foreground font-medium">Training</span>5 years historical data</div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
