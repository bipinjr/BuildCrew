import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { Camera, Upload, Leaf, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const recentScans = [
  { disease: "Early Blight", crop: "Tomato", severity: "High", confidence: 94, date: "2 hours ago" },
  { disease: "Healthy", crop: "Maize", severity: "None", confidence: 98, date: "Yesterday" },
  { disease: "Powdery Mildew", crop: "Grape", severity: "Medium", confidence: 89, date: "2 days ago" },
];

export default function DiseaseDetection() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Snap & Diagnose</h2>
          <p className="text-sm text-muted-foreground mt-1">Photo a leaf → 38 disease classes + severity + remedy in 4 seconds</p>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {/* Camera/Upload Area */}
          <motion.div
            whileHover={{ y: -2 }}
            className="col-span-1 border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
          >
            <Camera className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-sm font-semibold">Capture Leaf</p>
            <p className="text-xs text-muted-foreground mt-1">Use camera or upload image</p>
            <div className="flex gap-2 mt-4">
              <Button size="sm" variant="outline"><Camera className="w-3.5 h-3.5 mr-1" /> Camera</Button>
              <Button size="sm" variant="outline"><Upload className="w-3.5 h-3.5 mr-1" /> Upload</Button>
            </div>
          </motion.div>

          {/* Results Preview */}
          <div className="col-span-2 bg-card border rounded-lg p-6 shadow-ceramic">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Leaf className="w-4 h-4 text-primary" /> Recent Diagnoses
            </h3>
            <div className="space-y-3">
              {recentScans.map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center justify-between p-3 rounded-md border hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {s.severity !== "None" ? (
                      <AlertCircle className="w-4 h-4 text-alert" />
                    ) : (
                      <Leaf className="w-4 h-4 text-primary" />
                    )}
                    <div>
                      <p className="text-sm font-medium">{s.disease}</p>
                      <p className="text-[11px] text-muted-foreground">{s.crop} · {s.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={s.severity === "High" ? "destructive" : s.severity === "Medium" ? "secondary" : "default"}
                      className={`text-[10px] ${s.severity === "None" ? "bg-primary text-primary-foreground" : ""}`}
                    >
                      {s.severity === "None" ? "Healthy" : s.severity}
                    </Badge>
                    <span className="text-xs font-mono-data text-muted-foreground">{s.confidence}%</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Model Info */}
        <div className="bg-card border rounded-lg p-6 shadow-ceramic">
          <h3 className="text-sm font-semibold mb-3">Model Details</h3>
          <div className="grid grid-cols-4 gap-4 text-xs text-muted-foreground">
            <div><span className="block text-foreground font-medium">Architecture</span>MobileNetV2 + TFLite</div>
            <div><span className="block text-foreground font-medium">Classes</span>38 disease types</div>
            <div><span className="block text-foreground font-medium">Accuracy</span><span className="font-mono-data">91%</span> (PlantVillage)</div>
            <div><span className="block text-foreground font-medium">Inference</span>&lt;4 seconds · Offline</div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
