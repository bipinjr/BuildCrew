import DashboardLayout from "@/components/DashboardLayout";
import { motion } from "framer-motion";
import { Users, MessageCircle, ThumbsUp, Search, MapPin, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

const threads = [
  { author: "Ravi K.", location: "Kolar", topic: "Neem oil mix ratio for fall armyworm in maize?", replies: 12, likes: 34, tag: "Pest Control", time: "2h ago" },
  { author: "Lakshmi S.", location: "Mandya", topic: "Cold storage options near Kolar — any recommendations?", replies: 8, likes: 21, tag: "Market", time: "4h ago" },
  { author: "Mohan P.", location: "Hassan", topic: "Best rice variety for sandy loam soil in Karnataka", replies: 15, likes: 45, tag: "Crops", time: "6h ago" },
  { author: "Priya R.", location: "Shimoga", topic: "PM-KISAN application process — step by step guide", replies: 23, likes: 67, tag: "Schemes", time: "1d ago" },
  { author: "Kumar V.", location: "Kolar", topic: "Drip irrigation setup cost for 2 acres", replies: 9, likes: 18, tag: "Irrigation", time: "1d ago" },
];

const mentors = [
  { name: "Dr. Anand", speciality: "Entomology", rating: 4.9 },
  { name: "Prof. Meena", speciality: "Soil Science", rating: 4.8 },
  { name: "Sri Ramaiah", speciality: "Organic Farming", rating: 4.7 },
];

export default function Community() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Farmer Community</h2>
            <p className="text-sm text-muted-foreground mt-1">Peer Q&A, mentor match, voice-first wisdom archive</p>
          </div>
          <Badge variant="secondary" className="text-xs">1,247 members · 342 online</Badge>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-10" placeholder="Search threads, questions, or topics..." />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 space-y-3">
            {threads.map((t, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                className="bg-card border rounded-lg p-5 shadow-ceramic cursor-pointer hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <Badge variant="outline" className="text-[10px] mb-2">{t.tag}</Badge>
                    <p className="text-sm font-semibold leading-snug font-reading">{t.topic}</p>
                    <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
                      <span>{t.author}</span>
                      <span className="flex items-center gap-0.5"><MapPin className="w-2.5 h-2.5" />{t.location}</span>
                      <span>{t.time}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-4 mt-3 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" />{t.replies} replies</span>
                  <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" />{t.likes} likes</span>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="space-y-4">
            <div className="bg-card border rounded-lg p-5 shadow-ceramic">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> Trending Topics
              </h3>
              <div className="flex flex-wrap gap-2">
                {["Armyworm", "Rabi 2026", "Organic", "PM-KISAN", "Drip Irrigation", "Soil Health"].map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-[10px] cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors">{tag}</Badge>
                ))}
              </div>
            </div>

            <div className="bg-card border rounded-lg p-5 shadow-ceramic">
              <h3 className="text-sm font-semibold mb-3">Expert Mentors</h3>
              <div className="space-y-3">
                {mentors.map((m, i) => (
                  <div key={i} className="flex items-center justify-between text-xs p-2 rounded-md border">
                    <div>
                      <p className="font-medium text-foreground">{m.name}</p>
                      <p className="text-muted-foreground">{m.speciality}</p>
                    </div>
                    <span className="font-mono-data text-primary font-bold">★ {m.rating}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
