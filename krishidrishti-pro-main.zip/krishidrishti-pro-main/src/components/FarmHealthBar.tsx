import { motion } from "framer-motion";
import { Shield, Bug, Droplets, Thermometer } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function FarmHealthBar() {
  return (
    <header className="sticky top-0 z-30 border-b bg-card/80 backdrop-blur-sm px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-primary animate-pulse-ring" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Farm Health</p>
            <p className="text-xl font-bold font-mono-data tracking-tight text-foreground">87<span className="text-sm text-muted-foreground">/100</span></p>
          </div>
        </div>

        <div className="h-8 w-px bg-border" />

        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5"><Thermometer className="w-3.5 h-3.5" /> 32°C</span>
          <span className="flex items-center gap-1.5"><Droplets className="w-3.5 h-3.5" /> 68% Humidity</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <motion.div whileTap={{ scale: 0.98 }} className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-alert bg-alert/5 cursor-pointer">
          <Bug className="w-3.5 h-3.5 text-alert" />
          <span className="text-xs font-medium text-alert">2 Pest Alerts</span>
        </motion.div>
        <Badge variant="secondary" className="text-xs">Kolar District</Badge>
      </div>
    </header>
  );
}
