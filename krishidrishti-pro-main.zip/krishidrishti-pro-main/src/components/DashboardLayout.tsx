import { ReactNode } from "react";
import AppSidebar from "./AppSidebar";
import FarmHealthBar from "./FarmHealthBar";

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <AppSidebar />
      <div className="flex-1 ml-60 flex flex-col">
        <FarmHealthBar />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
