import { NavLink, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Leaf, Bug, TrendingUp, FlaskConical, BarChart3,
  Mic, CalendarDays, FileCheck, Users, Video, LayoutDashboard
} from "lucide-react";

const modules = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/disease-detection", icon: Leaf, label: "Snap & Diagnose" },
  { to: "/pest-monitoring", icon: Bug, label: "PestGuard" },
  { to: "/yield-predictor", icon: TrendingUp, label: "Yield Predictor" },
  { to: "/soil-scanner", icon: FlaskConical, label: "Soil Scanner" },
  { to: "/market-predictor", icon: BarChart3, label: "Market Predictor" },
  { to: "/voice-assistant", icon: Mic, label: "KrishiBot" },
  { to: "/crop-calendar", icon: CalendarDays, label: "Crop Calendar" },
  { to: "/scheme-matcher", icon: FileCheck, label: "Scheme Matcher" },
  { to: "/community", icon: Users, label: "Community" },
  { to: "/video-learning", icon: Video, label: "Video Library" },
];

export default function AppSidebar() {
  const location = useLocation();

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-60 bg-sidebar border-r border-sidebar-border flex flex-col z-40">
      <div className="p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <Leaf className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-sidebar-primary-foreground tracking-tight">KrishiDrishti</h1>
            <p className="text-[10px] text-sidebar-foreground opacity-60">3.0 + PestGuard</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-3 px-3 space-y-0.5 overflow-y-auto">
        {modules.map((m) => {
          const isActive = location.pathname === m.to;
          return (
            <NavLink key={m.to} to={m.to}>
              <motion.div
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.15, type: "spring" }}
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-[13px] font-medium transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`}
              >
                <m.icon className="w-4 h-4 shrink-0" />
                {m.label}
              </motion.div>
            </NavLink>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <p className="text-[10px] text-sidebar-foreground opacity-40">Build Crew · KLE S.N. College</p>
      </div>
    </aside>
  );
}
