import { motion } from "framer-motion";
import { CalendarDays, CheckCircle2, AlertCircle } from "lucide-react";

const tasks = [
  { text: "Spray neem oil — N4 sector", urgent: true },
  { text: "Irrigate paddy field B2", urgent: false },
  { text: "Soil test collection — S2", urgent: false },
];

export default function CropCalendarWidget() {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex items-center gap-2 mb-4">
        <CalendarDays className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold tracking-tight">Today's Tasks</h3>
      </div>

      <div className="space-y-3">
        {tasks.map((t, i) => (
          <div key={i} className="flex items-start gap-2 text-xs">
            {t.urgent ? (
              <AlertCircle className="w-3.5 h-3.5 text-alert mt-0.5 shrink-0" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
            )}
            <span className={t.urgent ? "text-foreground font-medium" : "text-muted-foreground"}>{t.text}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
