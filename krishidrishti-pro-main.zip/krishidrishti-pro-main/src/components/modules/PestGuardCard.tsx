import { motion } from "framer-motion";
import { Bug, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export default function PestGuardCard() {
  const navigate = useNavigate();
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border border-border border-t-4 border-t-alert rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex justify-between items-start">
        <Badge className="bg-alert text-alert-foreground border-0">Pest Detected</Badge>
        <span className="text-[11px] font-mono-data text-muted-foreground">ID: #442-B</span>
      </div>
      <h3 className="text-xl font-bold mt-4 tracking-tight">Fall Armyworm</h3>
      <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
        Detected in North Sector via scheduled phone scan. Infestation at 2.3% — immediate intervention required.
      </p>
      <div className="flex gap-2 mt-2">
        <Badge variant="outline" className="text-[10px]">Spodoptera frugiperda</Badge>
        <Badge variant="outline" className="text-[10px]">Maize · Sector N4</Badge>
      </div>
      <Button
        onClick={() => navigate("/pest-monitoring")}
        className="w-full mt-6 bg-foreground text-background hover:bg-foreground/90 transition-all"
      >
        View Treatment Plan <ArrowRight className="w-4 h-4 ml-1" />
      </Button>
    </motion.div>
  );
}
