import { motion } from "framer-motion";
import { Users, MessageCircle, ThumbsUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const threads = [
  { author: "Ravi K.", topic: "Neem oil mix ratio for armyworm?", replies: 12, likes: 34, tag: "Pest Control" },
  { author: "Lakshmi S.", topic: "Cold storage options near Kolar", replies: 8, likes: 21, tag: "Market" },
  { author: "Mohan P.", topic: "Best rice variety for sandy loam", replies: 15, likes: 45, tag: "Crops" },
];

export default function CommunityWidget() {
  return (
    <div className="bg-card border rounded-lg p-6 shadow-ceramic">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold tracking-tight">Community</h3>
        </div>
        <Badge variant="secondary" className="text-[10px]">342 online</Badge>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {threads.map((t, i) => (
          <motion.div
            key={i}
            whileHover={{ y: -2 }}
            className="border rounded-md p-4 cursor-pointer transition-colors hover:bg-muted/50"
          >
            <Badge variant="outline" className="text-[10px] mb-2">{t.tag}</Badge>
            <p className="text-sm font-medium leading-snug font-reading">{t.topic}</p>
            <p className="text-[11px] text-muted-foreground mt-1">by {t.author}</p>
            <div className="flex gap-3 mt-3 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" />{t.replies}</span>
              <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" />{t.likes}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
