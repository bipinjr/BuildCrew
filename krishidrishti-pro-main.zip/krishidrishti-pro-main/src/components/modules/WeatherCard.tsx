import { motion } from "framer-motion";
import { Cloud, Droplets, Wind, Sun } from "lucide-react";

export default function WeatherCard() {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex items-center gap-2 mb-4">
        <Cloud className="w-4 h-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold tracking-tight">Weather</h3>
      </div>

      <div className="flex items-center gap-3">
        <Sun className="w-10 h-10 text-alert" />
        <div>
          <p className="text-3xl font-bold font-mono-data tracking-tight text-foreground">32°</p>
          <p className="text-xs text-muted-foreground">Partly Cloudy</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-4 text-[11px] text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Droplets className="w-3 h-3" /> 68% Humidity
        </div>
        <div className="flex items-center gap-1.5">
          <Wind className="w-3 h-3" /> 12 km/h
        </div>
      </div>

      <p className="text-[10px] text-muted-foreground mt-4">Rain likely Thursday · IMD Forecast</p>
    </motion.div>
  );
}
