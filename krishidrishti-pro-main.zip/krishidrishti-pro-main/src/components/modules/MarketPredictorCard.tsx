import { motion } from "framer-motion";
import { BarChart3, TrendingDown, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { day: "Mon", price: 2400 },
  { day: "Tue", price: 2350 },
  { day: "Wed", price: 2500 },
  { day: "Thu", price: 2420 },
  { day: "Fri", price: 2380 },
  { day: "Sat", price: 2290 },
  { day: "Sun", price: 2200 },
];

export default function MarketPredictorCard() {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold tracking-tight">Tomato — Kolar Mandi</h3>
        </div>
        <Badge variant="outline" className="text-[10px] flex items-center gap-1">
          <TrendingDown className="w-3 h-3 text-alert" /> -8.3% forecast
        </Badge>
      </div>

      <div className="h-36">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0.15} />
                <stop offset="95%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
            <YAxis hide />
            <Tooltip
              contentStyle={{ fontSize: 11, borderRadius: 6, border: "1px solid hsl(142, 10%, 90%)" }}
              formatter={(value: number) => [`₹${value}/q`, "Price"]}
            />
            <Area type="monotone" dataKey="price" stroke="hsl(142, 76%, 36%)" strokeWidth={2} fill="url(#priceGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="flex justify-between mt-3 text-xs">
        <span className="text-muted-foreground">7-day forecast · 92% confidence</span>
        <span className="font-mono-data font-semibold text-foreground">₹2,200/q</span>
      </div>
    </motion.div>
  );
}
