import { motion } from "framer-motion";
import { Camera, Bug, Mic, FileCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";

const actions = [
  { icon: Camera, label: "Snap & Diagnose", to: "/disease-detection", desc: "Photo → Disease ID in 4s" },
  { icon: Bug, label: "PestGuard Scan", to: "/pest-monitoring", desc: "Run agentic pest check" },
  { icon: Mic, label: "Ask KrishiBot", to: "/voice-assistant", desc: "Voice query in your language" },
  { icon: FileCheck, label: "Check Schemes", to: "/scheme-matcher", desc: "Find eligible subsidies" },
];

export default function QuickActions() {
  const navigate = useNavigate();
  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((a) => (
        <motion.button
          key={a.to}
          whileTap={{ scale: 0.98 }}
          transition={{ duration: 0.15, type: "spring" }}
          onClick={() => navigate(a.to)}
          className="flex items-center gap-3 p-4 rounded-lg border bg-card shadow-ceramic hover:bg-muted/50 transition-colors text-left"
        >
          <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
            <a.icon className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-sm font-semibold tracking-tight">{a.label}</p>
            <p className="text-[11px] text-muted-foreground">{a.desc}</p>
          </div>
        </motion.button>
      ))}
    </div>
  );
}
