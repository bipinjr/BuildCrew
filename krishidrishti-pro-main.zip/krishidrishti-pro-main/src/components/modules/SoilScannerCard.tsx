import { motion } from "framer-motion";
import { FlaskConical } from "lucide-react";

const nutrients = [
  { label: "N", value: 72, color: "text-primary" },
  { label: "P", value: 45, color: "text-alert" },
  { label: "K", value: 88, color: "text-primary" },
];

export default function SoilScannerCard() {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex items-center gap-2 mb-4">
        <FlaskConical className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold tracking-tight">Soil Health</h3>
      </div>

      <div className="space-y-4">
        {nutrients.map((n) => (
          <div key={n.label}>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">{n.label === "N" ? "Nitrogen" : n.label === "P" ? "Phosphorus" : "Potassium"}</span>
              <span className={`font-mono-data font-bold ${n.color}`}>{n.value}%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${n.value}%` }}
                transition={{ duration: 1, delay: 0.2 }}
                className={`h-full rounded-full ${n.value > 60 ? "bg-primary" : "bg-alert"}`}
              />
            </div>
          </div>
        ))}
      </div>

      <p className="text-[11px] text-muted-foreground mt-4">pH: 6.8 · Sandy Loam · Sector S2</p>
    </motion.div>
  );
}
