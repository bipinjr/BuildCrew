import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";

export default function YieldPredictorCard() {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.15, type: "spring" }}
      className="h-full bg-card border rounded-lg p-6 shadow-ceramic"
    >
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold tracking-tight">Yield Forecast</h3>
      </div>

      <div className="text-center py-4">
        <p className="text-3xl font-bold font-mono-data tracking-tight text-foreground">24.5</p>
        <p className="text-xs text-muted-foreground mt-1">Bags / Acre</p>
        <div className="mt-3 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-medium">
          ±5% variance
        </div>
      </div>

      <div className="text-[11px] text-muted-foreground space-y-1 mt-2">
        <div className="flex justify-between"><span>Crop</span><span className="font-medium text-foreground">Maize</span></div>
        <div className="flex justify-between"><span>Season</span><span className="font-medium text-foreground">Kharif 2026</span></div>
        <div className="flex justify-between"><span>Model</span><span className="font-mono-data">RF Regressor</span></div>
      </div>
    </motion.div>
  );
}
