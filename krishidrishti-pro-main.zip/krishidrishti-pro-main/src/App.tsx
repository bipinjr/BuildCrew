import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "./pages/Home";
import Index from "./pages/Index";
import DiseaseDetection from "./pages/DiseaseDetection";
import PestMonitoring from "./pages/PestMonitoring";
import YieldPredictor from "./pages/YieldPredictor";
import SoilScanner from "./pages/SoilScanner";
import MarketPredictor from "./pages/MarketPredictor";
import VoiceAssistant from "./pages/VoiceAssistant";
import CropCalendar from "./pages/CropCalendar";
import SchemeMatcher from "./pages/SchemeMatcher";
import Community from "./pages/Community";
import VideoLearning from "./pages/VideoLearning";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Index />} />
          <Route path="/disease-detection" element={<DiseaseDetection />} />
          <Route path="/pest-monitoring" element={<PestMonitoring />} />
          <Route path="/yield-predictor" element={<YieldPredictor />} />
          <Route path="/soil-scanner" element={<SoilScanner />} />
          <Route path="/market-predictor" element={<MarketPredictor />} />
          <Route path="/voice-assistant" element={<VoiceAssistant />} />
          <Route path="/crop-calendar" element={<CropCalendar />} />
          <Route path="/scheme-matcher" element={<SchemeMatcher />} />
          <Route path="/community" element={<Community />} />
          <Route path="/video-learning" element={<VideoLearning />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
